package com.kafi.payments;

import android.app.Activity;
import android.os.Bundle;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int purple = Color.rgb(74, 35, 151);
    private final int pale = Color.rgb(241, 235, 255);
    private DB db;
    private EditText customer, amount, search;
    private Spinner method;
    private LinearLayout list;
    private TextView total;
    private String[] methods = {"حوالة بنكية", "بل بي", "جوال بي"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(purple);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        db = new DB();
        buildScreen();
        refresh("");
    }

    private GradientDrawable bg(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(2, stroke);
        return d;
    }
    private TextView text(String s, int size, boolean bold, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private EditText edit(String hint, int inputType) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextSize(16);
        e.setHint(hint); e.setInputType(inputType); e.setPadding(16, 8, 16, 8);
        e.setBackground(bg(Color.WHITE, 18, Color.rgb(220, 215, 232)));
        e.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL); return e;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = column(); root.setPadding(18, 12, 18, 20);
        root.setBackgroundColor(Color.rgb(250, 248, 255));
        scroll.addView(root);

        TextView header = text("دفعات الكافي", 27, true, Color.WHITE);
        header.setGravity(Gravity.CENTER); header.setBackground(bg(purple, 20, 0));
        header.setPadding(12, 14, 12, 14); root.addView(header, lp(-1, 62));

        TextView intro = text("إضافة دفعة جديدة", 21, true, purple);
        intro.setGravity(Gravity.CENTER); intro.setPadding(4, 16, 4, 12);
        root.addView(intro);

        root.addView(text("اسم الزبون", 16, true, Color.BLACK));
        customer = edit("أدخل اسم الزبون", android.text.InputType.TYPE_CLASS_TEXT);
        root.addView(customer, lp(-1, 54)); space(root, 12);

        root.addView(text("المبلغ (شيكل)", 16, true, Color.BLACK));
        amount = edit("أدخل المبلغ", android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        root.addView(amount, lp(-1, 54)); space(root, 12);

        root.addView(text("طريقة الدفع", 16, true, Color.BLACK));
        method = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, methods);
        method.setAdapter(adapter); method.setBackground(bg(Color.WHITE, 16, Color.rgb(220,215,232)));
        root.addView(method, lp(-1, 52)); space(root, 14);

        Button save = new Button(this); save.setText("＋  حفظ الدفعة");
        save.setTextSize(17); save.setTextColor(Color.WHITE); save.setAllCaps(false);
        save.setBackground(bg(purple, 18, 0)); root.addView(save, lp(-1, 54));
        save.setOnClickListener(v -> savePayment());

        TextView listTitle = text("قائمة الدفعات", 21, true, purple);
        listTitle.setPadding(0, 22, 0, 8); root.addView(listTitle);

        search = edit("بحث باسم الزبون...", android.text.InputType.TYPE_CLASS_TEXT);
        root.addView(search, lp(-1, 50));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){ refresh(s.toString()); }
            public void afterTextChanged(Editable e){}
        });

        list = column(); root.addView(list);
        total = text("إجمالي الدفعات: 0 شيكل", 18, true, purple);
        total.setGravity(Gravity.CENTER); total.setPadding(8, 14, 8, 14);
        total.setBackground(bg(pale, 16, 0)); LinearLayout.LayoutParams tp=lp(-1,-2); tp.topMargin=12; root.addView(total,tp);
        setContentView(scroll);
    }
    private void space(LinearLayout l, int h) { View v=new View(this); l.addView(v,lp(1,h)); }

    private void savePayment() {
        String n = customer.getText().toString().trim();
        String a = amount.getText().toString().trim();
        if (n.isEmpty()) { customer.setError("اكتب اسم الزبون"); return; }
        if (a.isEmpty()) { amount.setError("اكتب المبلغ"); return; }
        try {
            double value = Double.parseDouble(a);
            if (value <= 0) { amount.setError("أدخل مبلغاً أكبر من صفر"); return; }
            db.add(n, value, method.getSelectedItem().toString());
            customer.setText(""); amount.setText(""); method.setSelection(0);
            refresh(search.getText().toString());
            Toast.makeText(this, "تم حفظ الدفعة على الهاتف", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) { amount.setError("المبلغ غير صحيح"); }
    }

    private void refresh(String q) {
        if (list == null) return;
        list.removeAllViews();
        Cursor c = db.find(q);
        double sum = 0;
        if (c.moveToFirst()) {
            do {
                String name=c.getString(1), pay=c.getString(3), date=c.getString(4);
                double val=c.getDouble(2); sum += val;
                LinearLayout card=column(); card.setPadding(14,10,14,10);
                card.setBackground(bg(Color.WHITE,16,Color.rgb(235,231,243)));
                TextView nm=text(name,18,true,Color.rgb(28,22,48));
                TextView detail=text(String.format(Locale.US,"%.2f شيكل  •  %s",val,pay),15,false,Color.DKGRAY);
                TextView dt=text(date,12,false,Color.GRAY);
                card.addView(nm); card.addView(detail); card.addView(dt);
                LinearLayout.LayoutParams cp=lp(-1,-2); cp.topMargin=8; list.addView(card,cp);
            } while(c.moveToNext());
        } else {
            TextView empty=text("لا توجد دفعات مطابقة",15,false,Color.GRAY);
            empty.setGravity(Gravity.CENTER); empty.setPadding(8,20,8,20); list.addView(empty);
        }
        c.close();
        total.setText(String.format(Locale.US,"إجمالي الدفعات المعروضة: %.2f شيكل",sum));
    }

    private class DB extends SQLiteOpenHelper {
        DB(){ super(MainActivity.this,"kafi_payments.db",null,1); }
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, amount REAL NOT NULL, method TEXT NOT NULL, date TEXT NOT NULL)");
        }
        public void onUpgrade(SQLiteDatabase d,int oldV,int newV){}
        void add(String n,double a,String m){
            ContentValues v=new ContentValues(); v.put("name",n); v.put("amount",a); v.put("method",m);
            v.put("date",new SimpleDateFormat("yyyy/MM/dd HH:mm",Locale.getDefault()).format(new Date()));
            getWritableDatabase().insert("payments",null,v);
        }
        Cursor find(String q){
            return getReadableDatabase().rawQuery("SELECT * FROM payments WHERE name LIKE ? ORDER BY id DESC",
                    new String[]{"%"+q+"%"});
        }
    }
}
