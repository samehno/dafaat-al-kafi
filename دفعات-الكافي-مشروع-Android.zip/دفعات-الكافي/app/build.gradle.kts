plugins { id("com.android.application") }

android {
    namespace = "com.kafi.payments"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kafi.payments"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
